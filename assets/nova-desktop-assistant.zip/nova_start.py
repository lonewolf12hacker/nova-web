# -*- coding: utf-8 -*-
"""
Nova AI Assistant — Entry Point
Just wires the GUI to the Brain and starts everything.
"""
import threading
from nova import NovaBrain
from nova.gui import NovaGUI


def main():
    brain = NovaBrain()

    def on_listen():
        brain.start_listening()

    def on_stop():
        brain.stop_listening()

    def on_quit():
        brain.quit()

    gui = NovaGUI(
        on_listen_click=on_listen,
        on_stop_click=on_stop,
        on_quit=on_quit
    )
    brain.gui = gui
    root = gui.build()

    # Start brain services after a short delay (let GUI draw first)
    root.after(600, brain.start)

    # Log welcome message
    root.after(800, lambda: gui.log("Nova", f"Nova AI Assistant is online. Say something!"))

    root.mainloop()


if __name__ == "__main__":
    main()
