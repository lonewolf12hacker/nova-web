# -*- coding: utf-8 -*-
"""OS Control module: open apps, browser, files, system control."""
import os
import subprocess
import webbrowser


class OSControl:
    def __init__(self, log_fn):
        self.log = log_fn
        # Map keywords -> executable paths or UWP URIs
        self.app_aliases = {
            "notepad": "notepad.exe",
            "calculator": "calc.exe",
            "paint": "mspaint.exe",
            "camera": "microsoft.windows.camera:",
            "photos": "ms-photos:",
            "spotify": os.path.expandvars(r"%APPDATA%\Spotify\Spotify.exe"),
            "discord": os.path.expandvars(r"%LOCALAPPDATA%\Discord\Update.exe"),
            "chrome": r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            "firefox": r"C:\Program Files\Mozilla Firefox\firefox.exe",
            "edge": "msedge.exe",
            "explorer": "explorer.exe",
            "settings": "ms-settings:",
            "task manager": "taskmgr.exe",
            "store": "ms-windows-store:",
            "clock": "ms-clock:",
            "maps": "bingmaps:",
            "mail": "ms-outlook:",
            "calendar": "outlookcal:",
        }

    def open_application(self, app_name):
        app_name_lower = app_name.lower().strip()
        # Match alias
        target = None
        for key, val in self.app_aliases.items():
            if key in app_name_lower:
                target = val
                break

        if target is None:
            target = app_name

        self.log("System", f"Opening: {target}")

        # UWP URI or ms- protocol
        if ":" in target and "/" not in target:
            try:
                subprocess.Popen(["start", target], shell=True)
                return f"Opening {app_name}."
            except Exception as e:
                return f"Could not open {app_name}: {e}"

        # Regular executable
        try:
            subprocess.Popen([target], shell=True)
            return f"Opening {app_name}."
        except Exception as e:
            return f"Couldn't open {app_name}. Error: {e}"

    def search_web(self, query):
        url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
        webbrowser.open(url)
        return f"Searching for {query}."

    def open_file(self, path):
        try:
            os.startfile(path)
            return f"Opened file: {path}"
        except Exception as e:
            return f"Could not open file: {e}"

    def lock_pc(self):
        import ctypes
        ctypes.windll.user32.LockWorkStation()
        return "PC locked."

    def shutdown(self, delay_seconds=30):
        subprocess.Popen(f"shutdown /s /t {delay_seconds}", shell=True)
        return f"Shutdown scheduled in {delay_seconds} seconds."

    def cancel_shutdown(self):
        subprocess.Popen("shutdown /a", shell=True)
        return "Shutdown cancelled."

    def restart(self, delay_seconds=30):
        subprocess.Popen(f"shutdown /r /t {delay_seconds}", shell=True)
        return f"Restart scheduled in {delay_seconds} seconds."

    def set_volume(self, level):
        """Set system volume 0-100 via nircmd or PowerShell fallback."""
        try:
            vol = max(0, min(100, int(level)))
            ps_cmd = (
                "$obj = New-Object -ComObject WScript.Shell; "
                f"for ($i=0; $i -lt 50; $i++) {{ $obj.SendKeys([char]174) }};"  # mute vol to 0
                f"$target = [math]::Round({vol}/2); "
                f"for ($i=0; $i -lt $target; $i++) {{ $obj.SendKeys([char]175) }};"
            )
            subprocess.run(["powershell", "-Command", ps_cmd], timeout=10, capture_output=True)
            return f"Volume set to approximately {vol}%."
        except Exception as e:
            return f"Volume change failed: {e}"

    def take_screenshot(self, save_path=None):
        if save_path is None:
            save_path = os.path.join(os.path.expanduser("~"), "Desktop", "nova_screenshot.png")
        try:
            ps_cmd = (
                "Add-Type -AssemblyName System.Windows.Forms,System.Drawing;"
                "$screen = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds;"
                "$bmp = New-Object System.Drawing.Bitmap($screen.Width,$screen.Height);"
                "$g = [System.Drawing.Graphics]::FromImage($bmp);"
                "$g.CopyFromScreen([System.Drawing.Point]::Empty,[System.Drawing.Point]::Empty,$screen.Size);"
                f"$bmp.Save('{save_path}');"
            )
            subprocess.run(["powershell", "-Command", ps_cmd], timeout=15, capture_output=True)
            return f"Screenshot saved to {save_path}."
        except Exception as e:
            return f"Screenshot failed: {e}"

    def get_clipboard(self):
        try:
            import tkinter as tk
            root = tk.Tk()
            root.withdraw()
            text = root.clipboard_get()
            root.destroy()
            return text
        except Exception:
            return ""

    def set_clipboard(self, text):
        try:
            subprocess.run(f'echo {text} | clip', shell=True, timeout=5)
            return f"Copied to clipboard."
        except Exception as e:
            return f"Clipboard error: {e}"

    def create_folder(self, path):
        try:
            os.makedirs(path, exist_ok=True)
            return f"Created folder: {path}"
        except Exception as e:
            return f"Folder creation failed: {e}"

    def list_files(self, path="."):
        try:
            files = os.listdir(path)
            return "\n".join(files[:30]) if files else "Empty folder."
        except Exception as e:
            return f"Cannot list files: {e}"

    def search_local_files(self, name_pattern):
        import fnmatch
        root_search_paths = [
            "c:\\Users\\RLS",
            os.path.join(os.path.expanduser("~"), "Desktop"),
            os.path.join(os.path.expanduser("~"), "Documents")
        ]
        matches = []
        exclude_dirs = {".git", "node_modules", "AppData", ".gemini", "venv", ".idea", ".vscode"}
        for search_path in root_search_paths:
            if not os.path.exists(search_path):
                continue
            for root, dirs, files in os.walk(search_path):
                dirs[:] = [d for d in dirs if d not in exclude_dirs]
                for file in files:
                    if fnmatch.fnmatch(file.lower(), f"*{name_pattern.lower()}*"):
                        matches.append(os.path.join(root, file))
                        if len(matches) >= 5:
                            break
                if len(matches) >= 5:
                    break
        return matches

    def read_local_file(self, file_name):
        root_search_paths = [
            "c:\\Users\\RLS",
            os.path.join(os.path.expanduser("~"), "Desktop")
        ]
        exclude_dirs = {".git", "node_modules", "AppData", ".gemini"}
        filepath = None
        
        # Check if absolute path was given and exists
        if os.path.isabs(file_name) and os.path.exists(file_name):
            filepath = file_name
        else:
            for search_path in root_search_paths:
                if not os.path.exists(search_path):
                    continue
                for root, dirs, files in os.walk(search_path):
                    dirs[:] = [d for d in dirs if d not in exclude_dirs]
                    for file in files:
                        if file.lower() == file_name.lower() or file.lower() == f"{file_name.lower()}.txt" or file.lower() == f"{file_name.lower()}.md":
                            filepath = os.path.join(root, file)
                            break
                    if filepath:
                        break
                if filepath:
                    break
        
        if filepath:
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = [f.readline().strip() for _ in range(3)]
                content = " ".join([l for l in lines if l])
                if content:
                    return f"Content of {os.path.basename(filepath)}: {content}", filepath
                else:
                    return "The file appears to be empty.", filepath
            except Exception as e:
                return f"Error reading file: {e}", None
        else:
            return f"I could not locate the file {file_name}.", None

