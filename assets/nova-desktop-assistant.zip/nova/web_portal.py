# -*- coding: utf-8 -*-
"""Web portal module: Flask HTTPS server + ngrok tunnel + REST/WebSocket API."""
import threading
import os
import json
import ssl
from datetime import datetime
from flask import Flask, request, jsonify, render_template_string, send_from_directory


PORTAL_HTML = '''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Nova — Mobile Portal</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Inter:wght@300;400;600&display=swap" rel="stylesheet"/>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --accent: #00f7ff;
      --accent2: #7b2fff;
      --bg: #05070f;
      --card: rgba(255,255,255,0.04);
      --border: rgba(0,247,255,0.18);
      --text: #e4f0ff;
    }
    body { background: var(--bg); color: var(--text); font-family: 'Inter', sans-serif; min-height: 100vh; display: flex; flex-direction: column; align-items: center; }
    .nova-header { width: 100%; padding: 20px 24px; background: rgba(0,0,0,0.6); backdrop-filter: blur(10px); border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 12px; position: sticky; top: 0; z-index: 10; }
    .nova-logo { font-family: 'Orbitron', monospace; font-size: 1.5rem; font-weight: 900; color: var(--accent); text-shadow: 0 0 15px var(--accent); }
    .status-dot { width: 10px; height: 10px; border-radius: 50%; background: #00ff88; box-shadow: 0 0 8px #00ff88; animation: pulse 2s infinite; margin-left: auto; }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
    .portal-container { width: 100%; max-width: 480px; padding: 24px 16px; flex: 1; }
    .orb-section { display: flex; justify-content: center; margin-bottom: 28px; }
    .orb { width: 120px; height: 120px; border-radius: 50%; background: radial-gradient(circle at 40% 35%, #00f7ff, #7b2fff, #05070f); box-shadow: 0 0 40px rgba(0,247,255,0.4), 0 0 80px rgba(123,47,255,0.3); animation: orb-breathe 4s ease-in-out infinite; cursor: pointer; position: relative; transition: transform 0.2s; }
    .orb:hover { transform: scale(1.06); }
    .orb.listening { animation: orb-listen 0.4s ease-in-out infinite; box-shadow: 0 0 60px rgba(0,247,255,0.8); }
    .orb.speaking { animation: orb-speak 0.3s ease-in-out infinite alternate; }
    @keyframes orb-breathe { 0%,100%{transform:scale(1)} 50%{transform:scale(1.04)} }
    @keyframes orb-listen { 0%{transform:scale(0.96)} 100%{transform:scale(1.06)} }
    @keyframes orb-speak { from{transform:scale(1)} to{transform:scale(1.08)} }
    .orb-label { text-align: center; margin-top: 8px; font-size: 0.75rem; color: rgba(0,247,255,0.6); letter-spacing: 2px; text-transform: uppercase; }
    .mic-btn { display: flex; align-items: center; justify-content: center; gap: 10px; background: linear-gradient(135deg, var(--accent2), var(--accent)); border: none; border-radius: 50px; color: #fff; font-family: 'Inter', sans-serif; font-size: 1rem; font-weight: 600; padding: 14px 36px; cursor: pointer; width: 100%; margin-bottom: 16px; letter-spacing: 1px; box-shadow: 0 4px 30px rgba(0,247,255,0.25); transition: transform 0.15s, box-shadow 0.15s; }
    .mic-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 40px rgba(0,247,255,0.4); }
    .mic-btn:active { transform: translateY(1px); }
    .mic-btn.recording { background: linear-gradient(135deg, #ff2266, #ff6b2b); animation: btn-pulse 0.6s infinite; }
    @keyframes btn-pulse { 0%,100%{box-shadow:0 4px 30px rgba(255,34,102,0.4)} 50%{box-shadow:0 4px 60px rgba(255,34,102,0.8)} }
    .text-input-row { display: flex; gap: 10px; margin-bottom: 20px; }
    .text-input { flex: 1; background: var(--card); border: 1px solid var(--border); border-radius: 12px; color: var(--text); font-family: 'Inter', sans-serif; font-size: 0.95rem; padding: 12px 16px; outline: none; transition: border-color 0.2s; }
    .text-input:focus { border-color: var(--accent); }
    .send-btn { background: var(--accent); border: none; border-radius: 12px; color: var(--bg); font-weight: 700; padding: 12px 20px; cursor: pointer; font-size: 1.1rem; transition: transform 0.15s; }
    .send-btn:hover { transform: scale(1.05); }
    .reply-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 18px; backdrop-filter: blur(8px); }
    .reply-title { font-size: 0.7rem; letter-spacing: 2px; color: var(--accent); text-transform: uppercase; margin-bottom: 10px; }
    .reply-text { font-size: 0.95rem; color: var(--text); line-height: 1.6; min-height: 50px; }
    .history { margin-top: 20px; display: flex; flex-direction: column; gap: 10px; }
    .history-item { background: var(--card); border-radius: 10px; padding: 10px 14px; border-left: 3px solid var(--accent2); font-size: 0.85rem; opacity: 0.7; }
    .history-item .q { color: var(--accent); font-weight: 600; margin-bottom: 4px; }
    .error-text { color: #ff4466; font-size: 0.85rem; text-align: center; padding: 8px; }
    @media (min-width: 600px) { .portal-container { max-width: 600px; } }
  </style>
</head>
<body>
<header class="nova-header">
  <span class="nova-logo">⬡ NOVA</span>
  <span style="font-size:0.75rem;color:rgba(255,255,255,0.4);margin-left:8px;">AI PORTAL</span>
  <span class="status-dot" id="status-dot"></span>
</header>

<main class="portal-container">
  <div class="orb-section">
    <div>
      <div class="orb" id="orb" onclick="startListening()"></div>
      <div class="orb-label" id="orb-label">Tap orb or mic button</div>
    </div>
  </div>

  <button class="mic-btn" id="mic-btn" onclick="startListening()">
    🎤 Hold to Speak
  </button>

  <div class="text-input-row">
    <input class="text-input" id="text-input" type="text" placeholder="Or type a command..." onkeydown="if(event.key==='Enter')sendText()"/>
    <button class="send-btn" onclick="sendText()">→</button>
  </div>

  <div class="reply-card">
    <div class="reply-title">Nova says</div>
    <div class="reply-text" id="nova-reply">Ready. What can I do for you?</div>
  </div>

  <div class="history" id="history"></div>
</main>

<script>
const API = '';
let history = [];

function setStatus(mode) {
  const orb = document.getElementById('orb');
  const btn = document.getElementById('mic-btn');
  const label = document.getElementById('orb-label');
  orb.className = 'orb ' + (mode || '');
  if(mode==='listening') { btn.textContent = '🔴 Listening...'; btn.className='mic-btn recording'; label.textContent='Listening...'; }
  else if(mode==='speaking') { btn.textContent = '🔊 Speaking...'; btn.className='mic-btn'; label.textContent='Speaking...'; }
  else { btn.textContent = '🎤 Hold to Speak'; btn.className='mic-btn'; label.textContent='Tap orb or mic button'; }
}

async function sendCommand(cmd) {
  if (!cmd.trim()) return;
  setStatus('speaking');
  document.getElementById('nova-reply').textContent = '...';
  try {
    const res = await fetch(API+'/api/command', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({command: cmd})
    });
    const data = await res.json();
    document.getElementById('nova-reply').textContent = data.reply || data.error;
    addHistory(cmd, data.reply);
    if(data.reply && 'speechSynthesis' in window) {
      const utter = new SpeechSynthesisUtterance(data.reply);
      window.speechSynthesis.speak(utter);
    }
  } catch(e) {
    document.getElementById('nova-reply').textContent = 'Connection failed. Is Nova running?';
  }
  setStatus('');
}

function sendText() {
  const inp = document.getElementById('text-input');
  sendCommand(inp.value);
  inp.value = '';
}

function addHistory(q, r) {
  history.unshift({q,r});
  if(history.length > 5) history.pop();
  const container = document.getElementById('history');
  container.innerHTML = history.map(h=>`
    <div class="history-item">
      <div class="q">You: ${h.q}</div>
      <div>Nova: ${h.r||''}</div>
    </div>`).join('');
}

let recognition;
function startListening() {
  if(!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
    alert('Voice not supported in this browser over HTTP. Use Chrome with HTTPS.');
    return;
  }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SR();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  setStatus('listening');
  recognition.start();
  recognition.onresult = (e) => { sendCommand(e.results[0][0].transcript); };
  recognition.onerror = () => { setStatus(''); };
  recognition.onend = () => { if(document.getElementById('orb').classList.contains('listening')) setStatus(''); };
}
</script>
</body>
</html>'''


def create_portal_app(nova_brain, log_fn):
    """Create and return the Flask app. nova_brain is the main Nova controller."""
    app = Flask(__name__, static_folder=None)
    app.secret_key = os.urandom(24)

    @app.after_request
    def add_cors_headers(response):
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        return response

    @app.route("/")
    def index():
        return render_template_string(PORTAL_HTML)

    @app.route("/api/command", methods=["POST", "OPTIONS"])
    def command():
        if request.method == "OPTIONS":
            return "", 204
        data = request.get_json(force=True)
        cmd = (data.get("command") or "").strip()
        if not cmd:
            return jsonify({"error": "empty command"}), 400
        try:
            reply = nova_brain.process_command(cmd)
            return jsonify({"reply": reply, "timestamp": datetime.now().isoformat()})
        except Exception as e:
            log_fn("Web", f"Command error: {e}")
            return jsonify({"error": str(e)}), 500

    @app.route("/api/status")
    def status():
        return jsonify({"status": "ok", "version": "2.0"})

    return app


def start_portal(nova_brain, log_fn, host="0.0.0.0", port=5000):
    """Start the Flask server and optionally open an ngrok tunnel. Non-blocking."""
    app = create_portal_app(nova_brain, log_fn)
    public_url = None

    # Try ngrok
    ngrok_token = os.environ.get("NGROK_TOKEN", "")
    if not ngrok_token:
        # Try reading from config file
        config_token_path = os.path.join(os.path.dirname(__file__), "..", "ngrok_token.txt")
        if os.path.exists(config_token_path):
            with open(config_token_path) as f:
                ngrok_token = f.read().strip()

    if ngrok_token:
        try:
            from pyngrok import ngrok, conf
            conf.get_default().auth_token = ngrok_token
            tunnel = ngrok.connect(port, "http")
            public_url = tunnel.public_url
            log_fn("Web", f"🌐 Global URL: {public_url}")
            log_fn("Web", "Share this URL to access Nova from anywhere!")
        except ImportError:
            log_fn("Web", "pyngrok not installed. Run: pip install pyngrok")
        except Exception as e:
            log_fn("Web", f"ngrok error: {e}")
    else:
        log_fn("Web", "No ngrok token. Add token to ngrok_token.txt for global access.")

    def _serve():
        try:
            import logging as pylog
            pylog.getLogger('werkzeug').disabled = True
            log_fn("Web", f"Starting web portal on http://0.0.0.0:{port}")
            app.run(host=host, port=port, debug=False, use_reloader=False)
        except Exception as e:
            log_fn("Web", f"Portal failed: {e}")

    t = threading.Thread(target=_serve, daemon=True)
    t.start()
    return public_url
