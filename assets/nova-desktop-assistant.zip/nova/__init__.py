# -*- coding: utf-8 -*-
"""Nova package — main brain. Wires all modules together."""
import os
import re
import threading
from nova.config import OLLAMA_EXE, WEB_PORT, APP_NAME
from nova.llm import LLMEngine
from nova.speech import SpeechEngine
from nova.os_control import OSControl
from nova.gui import NovaGUI


class NovaBrain:
    """Central controller that dispatches commands to the correct module."""

    def __init__(self):
        self.gui = None  # set by launcher
        self._stop_event = threading.Event()
        self._listen_thread = None
        self.llm = LLMEngine(self._log)
        self.speech = SpeechEngine(self._log)
        self.os_ctrl = OSControl(self._log)
        self._speaking = False
        self._listening = False
        self.session_active = False
        self.session_last_heard = 0
        self.session_timeout = 30


    # ── Logging ──────────────────────────────────────────────────────────────
    def _log(self, speaker, text):
        print(f"[{speaker}] {text}")
        if self.gui:
            self.gui.log(speaker, text)

    # ── Command dispatcher ────────────────────────────────────────────────────
    def process_command(self, cmd):
        cmd_l = cmd.lower().strip()

        # --- Voice-responsive closing / exit ---
        if any(w in cmd_l for w in ["close", "exit", "shutdown assistant"]):
            if self.gui and self.gui.root:
                self.gui.root.after(1500, self.gui._safe_quit)
            return "Goodbye!"

        # --- Window controls ---
        if "hide" in cmd_l or "minimize" in cmd_l:
            if self.gui:
                self.gui.hide()
            return "Hiding dashboard."

        if "show window" in cmd_l or "restore window" in cmd_l or "open window" in cmd_l:
            if self.gui:
                self.gui.restore()
            return "Restoring display."

        # --- Local File Operations ---
        if "search file" in cmd_l or "find file" in cmd_l:
            target = re.sub(r"\b(search file named|search file|find file)\b", "", cmd_l).strip()
            if target:
                matches = self.os_ctrl.search_local_files(target)
                if matches:
                    self._log("System", f"Matches found: {', '.join(matches)}")
                    return f"Found {len(matches)} files matching your request. Listing them in the system log."
                else:
                    return f"No files matching {target} were found."
            else:
                return "Please specify the file name you are looking for."

        if "read file" in cmd_l:
            target = re.sub(r"\b(read file)\b", "", cmd_l).strip()
            if target:
                reply, path = self.os_ctrl.read_local_file(target)
                if path:
                    self._log("System", f"Read file: {path}")
                return reply
            else:
                return "Please specify the file you want to read."

        # --- OS control patterns ---
        if re.search(r"\b(open|launch|start)\b", cmd_l):
            target = re.sub(r"\b(open|launch|start|please)\b", "", cmd_l).strip()
            if target:
                return self.os_ctrl.open_application(target)

        # --- Web search engines ---
        if "youtube" in cmd_l and "search" in cmd_l:
            query = re.sub(r"\b(search youtube for|youtube search|search|for|on youtube)\b", "", cmd_l).strip()
            import webbrowser
            webbrowser.open(f"https://www.youtube.com/results?search_query={query}")
            return f"Searching YouTube for {query}."

        if "wikipedia" in cmd_l and "search" in cmd_l:
            query = re.sub(r"\b(search wikipedia for|wikipedia search|search|for|on wikipedia)\b", "", cmd_l).strip()
            import webbrowser
            webbrowser.open(f"https://en.wikipedia.org/wiki/{query}")
            return f"Searching Wikipedia for {query}."

        if "search" in cmd_l and ("for" in cmd_l or "google" in cmd_l):
            query = re.sub(r"\b(search|for|google|web|on|please)\b", "", cmd_l).strip()
            return self.os_ctrl.search_web(query)

        if "screenshot" in cmd_l:
            return self.os_ctrl.take_screenshot()

        if "lock" in cmd_l and ("pc" in cmd_l or "computer" in cmd_l or "screen" in cmd_l):
            return self.os_ctrl.lock_pc()

        if "shutdown" in cmd_l or "shut down" in cmd_l:
            delay = 30
            m = re.search(r"(\d+)\s*(second|minute)", cmd_l)
            if m:
                delay = int(m.group(1)) * (60 if "minute" in m.group(2) else 1)
            return self.os_ctrl.shutdown(delay)

        if "cancel shutdown" in cmd_l:
            return self.os_ctrl.cancel_shutdown()

        if "restart" in cmd_l or "reboot" in cmd_l:
            return self.os_ctrl.restart()

        if "volume" in cmd_l:
            m = re.search(r"(\d+)", cmd_l)
            if m:
                return self.os_ctrl.set_volume(int(m.group(1)))

        if "list files" in cmd_l or "show files" in cmd_l:
            path = re.sub(r"\b(list|show|files?|in|folder|directory)\b", "", cmd_l).strip()
            return self.os_ctrl.list_files(path or ".")

        if re.search(r"\b(time|what time)\b", cmd_l):
            import datetime
            return f"It's {datetime.datetime.now().strftime('%I:%M %p')}."

        if re.search(r"\b(date|today|what day)\b", cmd_l):
            import datetime
            return f"Today is {datetime.datetime.now().strftime('%A, %B %d %Y')}."

        if re.search(r"\bclear.*(history|memory|conversation)\b", cmd_l):
            self.llm.clear_history()
            return "Memory cleared."

        if re.search(r"\bhello\b|\bhi nova\b|\bhey nova\b", cmd_l):
            return f"Hey! I'm {APP_NAME}. How can I help?"

        if "joke" in cmd_l:
            import random
            from nova.config import JOKES
            return random.choice(JOKES)

        # Fallback: AI chat
        return self.llm.chat(cmd)


    # ── Voice listener loop ───────────────────────────────────────────────────
    def _listen_loop(self):
        import time
        self._log("System", "Voice listener started. Say 'Nova' to activate.")
        self.session_active = False

        while not self._stop_event.is_set():
            if self._speaking:
                threading.Event().wait(0.3)
                continue

            try:
                # 1. Handle active session timeout
                if self.session_active:
                    elapsed = time.time() - self.session_last_heard
                    if elapsed > self.session_timeout:
                        self.session_active = False
                        self._log("System", "Session timed out. Back to standby.")
                        if self.gui:
                            self.gui.set_state("idle")
                        self._speaking = True
                        self.speech.speak(
                            "Going back to standby. Say Nova to wake me again.",
                            on_done=lambda: self._set_speaking(False)
                        )
                        continue

                # Set GUI state based on session status
                if self.gui:
                    if self.session_active:
                        self.gui.set_state("listening")
                    else:
                        self.gui.set_state("idle")

                # 2. Record audio with VAD
                wav = self.speech.record_with_vad()
                if wav is None:
                    continue

                if self.gui:
                    self.gui.set_state("thinking")

                # 3. Transcribe
                phrase = self.speech.transcribe(wav).lower().strip()
                if not phrase:
                    continue

                # 4. Handle active session commands
                if self.session_active:
                    self._log("Heard", f"Session command: '{phrase}'")
                    self.session_last_heard = time.time()

                    # Sleep/deactivate commands
                    if any(w in phrase for w in ["sleep", "go to sleep", "goodbye", "stand by", "standby"]):
                        self.session_active = False
                        self._log("System", "Session ended by user.")
                        if self.gui:
                            self.gui.set_state("idle")
                        self._speaking = True
                        self.speech.speak(
                            "Going to standby. Say Nova when you need me.",
                            on_done=lambda: self._set_speaking(False)
                        )
                    else:
                        # Clean prefix if user still says the wake word
                        for wake in ["nova ", "over "]:
                            if phrase.startswith(wake):
                                phrase = phrase[len(wake):].strip()
                                break
                        
                        if phrase:
                            self._log("User", phrase)
                            reply = self.process_command(phrase)
                            self._log("Nova", reply)
                            self._speaking = True
                            if self.gui:
                                self.gui.set_state("speaking")
                            self.speech.speak(
                                reply,
                                on_done=lambda: self._set_speaking(False)
                            )
                
                # 5. Handle standby mode (waiting for wake word)
                else:
                    self._log("System", f"Heard (standby): '{phrase}'")
                    if "nova" in phrase or "over" in phrase or "nov" in phrase:
                        self.speech.play_wake_sound()
                        self._log("System", "Wake word detected. Session started.")
                        self.session_active = True
                        self.session_last_heard = time.time()
                        if self.gui:
                            self.gui.set_state("listening")

                        # Extract inline command if any
                        command = phrase
                        for wake in ["nova", "over", "nov"]:
                            if wake in command:
                                command = command.split(wake, 1)[-1].strip()
                                break

                        if command and len(command) > 2:
                            self._log("Heard", f"Inline command: '{command}'")
                            self._log("User", command)
                            reply = self.process_command(command)
                            self._log("Nova", reply)
                            self._speaking = True
                            if self.gui:
                                self.gui.set_state("speaking")
                            self.speech.speak(
                                reply,
                                on_done=lambda: self._set_speaking(False)
                            )
                        else:
                            self._speaking = True
                            self.speech.speak(
                                "I'm listening. Go ahead.",
                                on_done=lambda: self._set_speaking(False)
                            )

            except Exception as e:
                self._log("Error", str(e))
                if self.gui:
                    self.gui.set_state("idle")


    def _set_speaking(self, val):
        self._speaking = val
        if self.gui and not val:
            self.gui.set_state("idle")

    # ── Lifecycle ─────────────────────────────────────────────────────────────
    def start(self):
        """Start all background services."""
        # Load Vosk in background
        threading.Thread(target=self.speech.load_vosk, daemon=True).start()
        # Calibrate mic
        threading.Thread(target=self.speech.calibrate_noise_floor, daemon=True).start()
        # Start Ollama
        threading.Thread(target=lambda: self.llm.start(OLLAMA_EXE), daemon=True).start()
        # Start web portal
        from nova.web_portal import start_portal
        public_url = start_portal(self, self._log, port=WEB_PORT)
        if public_url:
            self._log("Web", f"Global URL active: {public_url}")

    def start_listening(self):
        if self._listen_thread and self._listen_thread.is_alive():
            return
        self._stop_event.clear()
        self._listen_thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._listen_thread.start()

    def stop_listening(self):
        self._stop_event.set()
        if self.gui:
            self.gui.set_state("idle")

    def quit(self):
        self.stop_listening()
