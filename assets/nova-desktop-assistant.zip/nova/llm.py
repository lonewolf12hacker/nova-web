# -*- coding: utf-8 -*-
"""LLM module: handles all Ollama local AI communications."""
import requests
from nova.config import OLLAMA_URL, OLLAMA_MODEL, SYSTEM_PROMPT


class LLMEngine:
    def __init__(self, log_fn):
        self.log = log_fn
        self.ollama_url = OLLAMA_URL
        self.ollama_model = OLLAMA_MODEL
        self.system_prompt = SYSTEM_PROMPT
        self.conversation_history = []
        self.ready = False

    def start(self, ollama_exe_path):
        """Auto-start Ollama and confirm model is available."""
        import os, subprocess, time
        if not os.path.exists(ollama_exe_path):
            self.log("System", "Ollama not found. AI chat unavailable.")
            return

        # Check if already running
        try:
            resp = requests.get("http://localhost:11434/", timeout=2)
            if resp.status_code == 200:
                self.log("System", "Ollama already running. AI chat ready.")
                self._ensure_model()
                return
        except Exception:
            pass

        self.log("System", "Starting Ollama AI engine...")
        try:
            subprocess.Popen(
                [ollama_exe_path, "serve"],
                creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True
            )
        except Exception as e:
            self.log("System", f"Failed to start Ollama: {e}")
            return

        for i in range(30):
            time.sleep(1)
            try:
                if requests.get("http://localhost:11434/", timeout=1).status_code == 200:
                    self.log("System", "Ollama server is up! Checking model...")
                    self._ensure_model()
                    return
            except Exception:
                pass
        self.log("System", "Ollama server did not start in time.")

    def _ensure_model(self):
        try:
            tags = requests.get("http://localhost:11434/api/tags", timeout=5).json()
            models = [m["name"] for m in tags.get("models", [])]
            if any(self.ollama_model in m for m in models):
                self.log("System", f"AI model '{self.ollama_model}' ready. Nova AI chat enabled!")
                self.ready = True
                return
            self.log("System", f"Downloading AI model '{self.ollama_model}'...")
            resp = requests.post(
                "http://localhost:11434/api/pull",
                json={"name": self.ollama_model, "stream": False},
                timeout=600
            )
            if resp.status_code == 200:
                self.log("System", "AI model ready!")
                self.ready = True
        except Exception as e:
            self.log("System", f"Model check error: {e}")

    def chat(self, question):
        """Send a question to the LLM and return the answer string."""
        if not self.ready:
            return "My AI brain is still loading. Give me a moment and try again."
        messages = [{"role": "system", "content": self.system_prompt}]
        messages += self.conversation_history
        messages.append({"role": "user", "content": question})
        try:
            resp = requests.post(
                self.ollama_url,
                json={"model": self.ollama_model, "messages": messages, "stream": False},
                timeout=30
            )
            resp.raise_for_status()
            answer = resp.json()["message"]["content"].strip()
            self.conversation_history.append({"role": "user", "content": question})
            self.conversation_history.append({"role": "assistant", "content": answer})
            if len(self.conversation_history) > 20:
                self.conversation_history = self.conversation_history[-20:]
            return answer
        except requests.exceptions.ConnectionError:
            return "My AI brain isn't connected. Make sure Ollama is running."
        except Exception as e:
            return f"I ran into an issue: {e}"

    def clear_history(self):
        self.conversation_history = []
