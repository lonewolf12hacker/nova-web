# -*- coding: utf-8 -*-
"""Nova AI Assistant — Central configuration."""
import os

APP_NAME = "Nova"
APP_VERSION = "2.0"

OLLAMA_EXE = os.path.expandvars(r"%LOCALAPPDATA%\Programs\Ollama\ollama.exe")

JOKES = [
    "Why do programmers wear glasses? Because they can't C sharp.",
    "There are 10 types of people in the world: those who understand binary, and those who don't.",
    "How many programmers does it take to change a light bulb? None, that's a hardware problem.",
    "A SQL query goes into a bar, walks up to two tables and asks, 'Can I join you?'",
    "Why do Java programmers have to wear glasses? Because they don't C sharp."
]

# LLM Config
OLLAMA_URL = "http://localhost:11434/api/chat"
OLLAMA_MODEL = "llama3.2:1b"
SYSTEM_PROMPT = (
    "You are Nova, a friendly and helpful AI assistant running locally on the user's computer. "
    "Keep all answers concise (2-3 sentences max) since you will be spoken aloud via text-to-speech. "
    "Be conversational, warm, and helpful. Do not use bullet points, markdown, or special characters."
)

# Audio / STT Config
MIC_DEVICE_INDEX = 2
SAMPLE_RATE = 16000
SILENCE_THRESHOLD = 200
MIN_VOICE_FRAMES = 5
SESSION_TIMEOUT = 30

# Web Portal Config
WEB_PORT = 5000
