# -*- coding: utf-8 -*-
"""Speech module: VAD recording, Vosk offline STT, Google online STT, PowerShell TTS."""
import io
import json
import wave
import threading
import subprocess
import numpy as np
import sounddevice as sd
import speech_recognition as sr
import vosk

from nova.config import MIC_DEVICE_INDEX, SAMPLE_RATE, MIN_VOICE_FRAMES


class SpeechEngine:
    def __init__(self, log_fn):
        self.log = log_fn
        self.recognizer = sr.Recognizer()
        self.vosk_model = None
        self.mic_device_index = MIC_DEVICE_INDEX
        self.sample_rate = SAMPLE_RATE
        self.silence_threshold = 200
        self.min_voice_frames = MIN_VOICE_FRAMES
        self.current_rms = 0
        self._speaking = False

    def load_vosk(self):
        """Load Vosk offline model (call in a background thread)."""
        self.log("System", "Loading offline speech model...")
        try:
            self.vosk_model = vosk.Model(lang="en-us")
            self.log("System", "Offline speech model loaded successfully.")
        except Exception as e:
            self.log("System", f"Offline speech model failed: {e}")

    def calibrate_noise_floor(self):
        """Measure 1 second of ambient noise and set threshold 40% above it."""
        fs = self.sample_rate
        chunk = int(fs * 0.1)
        samples = []
        try:
            self.log("System", "Calibrating mic noise floor (1 sec)... stay quiet.")
            with sd.InputStream(samplerate=fs, channels=1, dtype='int16',
                                device=self.mic_device_index, blocksize=chunk) as stream:
                for _ in range(10):
                    data, _ = stream.read(chunk)
                    rms = int(np.sqrt(np.mean(data.astype(np.float32) ** 2)))
                    samples.append(rms)
            noise_floor = max(samples)
            self.silence_threshold = int(noise_floor * 1.4)
            self.log("System", f"Noise floor: {noise_floor} RMS -> threshold set to {self.silence_threshold}")
        except Exception as e:
            self.log("System", f"Calibration failed, using default threshold: {e}")

    def record_with_vad(self, max_seconds=6, chunk_ms=100):
        """Record audio using Voice Activity Detection. Returns WAV bytes or None."""
        fs = self.sample_rate
        chunk_size = int(fs * chunk_ms / 1000)
        max_chunks = int(max_seconds * 1000 / chunk_ms)
        silence_after_speech = int(1500 / chunk_ms)

        voiced_frames, total_frames = [], []
        consecutive_silence = 0
        speech_started = False

        try:
            with sd.InputStream(samplerate=fs, channels=1, dtype='int16',
                                device=self.mic_device_index, blocksize=chunk_size) as stream:
                for _ in range(max_chunks):
                    chunk, _ = stream.read(chunk_size)
                    rms = int(np.sqrt(np.mean(chunk.astype(np.float32) ** 2)))
                    self.current_rms = rms
                    is_voice = rms > self.silence_threshold
                    if is_voice:
                        speech_started = True
                        consecutive_silence = 0
                        voiced_frames.append(1)
                    else:
                        consecutive_silence += 1
                        voiced_frames.append(0)
                    total_frames.append(chunk)
                    if speech_started and consecutive_silence >= silence_after_speech:
                        break
        except Exception as e:
            self.log("System", f"Mic error (device {self.mic_device_index}): {e}")
            return None

        voice_count = sum(voiced_frames)
        self.log("System", f"VAD: {voice_count}/{len(voiced_frames)} voiced chunks (threshold={self.silence_threshold})")

        if voice_count < self.min_voice_frames:
            return None

        audio_data = np.concatenate(total_frames, axis=0)
        wav_io = io.BytesIO()
        with wave.open(wav_io, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(fs)
            wf.writeframes(audio_data.tobytes())
        wav_io.seek(0)
        return wav_io

    def transcribe(self, wav_io):
        """Transcribe WAV audio. Uses Vosk offline first, falls back to Google."""
        phrase = ""

        # Try Vosk offline
        if self.vosk_model:
            try:
                wav_io.seek(0)
                with wave.open(wav_io, 'rb') as wf:
                    rec = vosk.KaldiRecognizer(self.vosk_model, wf.getframerate())
                    rec.SetWords(False)
                    pcm_data = wf.readframes(wf.getnframes())
                    result = json.loads(rec.Result() if rec.AcceptWaveform(pcm_data) else rec.FinalResult())
                    phrase = result.get("text", "").lower().strip()
            except Exception as e:
                self.log("System", f"Offline STT error: {e}")

        # Google fallback
        if not phrase:
            try:
                wav_io.seek(0)
                with sr.AudioFile(wav_io) as source:
                    audio = self.recognizer.record(source)
                phrase = self.recognizer.recognize_google(audio).lower().strip()
            except sr.UnknownValueError:
                pass
            except Exception as e:
                self.log("System", f"Online STT error: {e}")

        return phrase

    def speak(self, text, on_start=None, on_done=None):
        """Speak text using Windows PowerShell SAPI. Non-blocking."""
        def _do_speak():
            if on_start:
                on_start()
            try:
                safe_text = text.replace("'", "''").replace('"', '')
                ps_cmd = (
                    "Add-Type -AssemblyName System.Speech; "
                    "$voice = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                    "$voice.Rate = 1; "
                    f"$voice.Speak('{safe_text}');"
                )
                subprocess.run(
                    ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
                    timeout=60, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
            except Exception as e:
                print(f"TTS error: {e}")
            finally:
                if on_done:
                    on_done()
        threading.Thread(target=_do_speak, daemon=True).start()

    def play_wake_sound(self):
        try:
            import winsound
            winsound.Beep(1200, 150)
            winsound.Beep(1500, 100)
        except Exception:
            pass

    def play_stop_sound(self):
        try:
            import winsound
            winsound.Beep(900, 150)
        except Exception:
            pass

