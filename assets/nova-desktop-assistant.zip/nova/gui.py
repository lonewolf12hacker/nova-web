# -*- coding: utf-8 -*-
"""GUI module: Tkinter HUD with animated canvas, console, and controls."""
import math
import time
import threading
import tkinter as tk
from tkinter import scrolledtext
from nova.config import APP_NAME, APP_VERSION


class NovaGUI:
    def __init__(self, on_listen_click, on_stop_click, on_quit):
        self.on_listen_click = on_listen_click
        self.on_stop_click = on_stop_click
        self.on_quit = on_quit
        self.root = None
        self.canvas = None
        self.console = None
        self.state_label = None
        self.listen_btn = None
        self._orb_angle = 0
        self._orb_rms = 0
        self._orb_running = False
        self._state = "idle"  # idle | listening | speaking | thinking

    def build(self):
        self.root = tk.Tk()
        self.root.title(f"⬡ {APP_NAME} v{APP_VERSION}")
        self.root.configure(bg="#05070f")
        self.root.resizable(True, True)
        self.root.minsize(500, 680)
        self.root.protocol("WM_DELETE_WINDOW", self._safe_quit)

        # --- Canvas (orb visualizer) ---
        self.canvas = tk.Canvas(self.root, width=280, height=280, bg="#05070f", highlightthickness=0)
        self.canvas.pack(pady=(24, 0))
        self._draw_orb()

        # --- State label ---
        self.state_label = tk.Label(
            self.root, text="IDLE", font=("Courier", 10, "bold"),
            bg="#05070f", fg="#00f7ff", pady=4
        )
        self.state_label.pack()

        # --- Buttons row ---
        btn_frame = tk.Frame(self.root, bg="#05070f")
        btn_frame.pack(pady=12)
        self.listen_btn = tk.Button(
            btn_frame, text="🎤  SPEAK", font=("Courier", 11, "bold"),
            bg="#7b2fff", fg="white", relief="flat",
            padx=22, pady=10, cursor="hand2",
            activebackground="#00f7ff", activeforeground="#05070f",
            command=self.on_listen_click
        )
        self.listen_btn.pack(side=tk.LEFT, padx=6)

        stop_btn = tk.Button(
            btn_frame, text="⏹  STOP", font=("Courier", 11, "bold"),
            bg="#1a1a2e", fg="#ff4466", relief="flat",
            padx=22, pady=10, cursor="hand2",
            activebackground="#ff4466", activeforeground="white",
            command=self.on_stop_click
        )
        stop_btn.pack(side=tk.LEFT, padx=6)

        quit_btn = tk.Button(
            btn_frame, text="✕", font=("Courier", 11, "bold"),
            bg="#1a1a2e", fg="#888", relief="flat",
            padx=12, pady=10, cursor="hand2",
            activebackground="#ff4466", activeforeground="white",
            command=self._safe_quit
        )
        quit_btn.pack(side=tk.LEFT, padx=6)

        # --- Separator ---
        sep = tk.Frame(self.root, bg="#00f7ff", height=1)
        sep.pack(fill=tk.X, padx=20, pady=(8, 0))

        # --- Console ---
        console_label = tk.Label(
            self.root, text="SYSTEM LOG", font=("Courier", 8),
            bg="#05070f", fg="#444"
        )
        console_label.pack(anchor="w", padx=20)

        self.console = scrolledtext.ScrolledText(
            self.root, font=("Courier", 9), bg="#080b14",
            fg="#00f7ff", insertbackground="#00f7ff",
            relief="flat", padx=10, pady=8, height=14,
            wrap=tk.WORD, state=tk.DISABLED
        )
        self.console.pack(fill=tk.BOTH, expand=True, padx=16, pady=(0, 16))
        self.console.tag_config("user", foreground="#ffffff")
        self.console.tag_config("nova", foreground="#00f7ff")
        self.console.tag_config("system", foreground="#888888")
        self.console.tag_config("error", foreground="#ff4466")

        # Start orb animation
        self._orb_running = True
        self._animate_orb()
        return self.root

    def _draw_orb(self):
        c = self.canvas
        c.delete("all")
        cx, cy, r = 140, 140, 70
        t = self._orb_angle

        # Glow rings
        for i, (radius, alpha) in enumerate([(100, 0.06), (86, 0.1), (80, 0.15)]):
            alpha_hex = f"{int(alpha * 255):02x}"
            color = f"#00f7ff" if self._state in ("listening",) else "#7b2fff"
            c.create_oval(cx-radius, cy-radius, cx+radius, cy+radius,
                          outline=f"#{int(alpha*255):02x}f7ff" if self._state=="listening" else f"#7b2f{int(alpha*255):02x}",
                          width=1)

        # Pulse if listening
        if self._state == "listening":
            pulse = 5 * math.sin(t * 4)
            r = int(r + pulse + (self._orb_rms / 100))

        # Main orb gradient simulation (concentric circles)
        for i in range(r, 0, -4):
            ratio = i / r
            red = int(0 + ratio * 0)
            green = int(ratio * 247 * (1 - ratio) * 2)
            blue = int(255 * ratio)
            color = f"#{red:02x}{min(255,green):02x}{min(255,blue):02x}"
            c.create_oval(cx-i, cy-i, cx+i, cy+i, fill=color, outline="")

        # Rotating particle ring
        for i in range(12):
            angle = t + (i * math.pi * 2 / 12)
            orbit_r = 90 + 5 * math.sin(t * 2)
            px = cx + orbit_r * math.cos(angle)
            py = cy + orbit_r * math.sin(angle)
            size = 2 + 1.5 * math.sin(t * 3 + i)
            color = "#00f7ff" if i % 2 == 0 else "#7b2fff"
            c.create_oval(px-size, py-size, px+size, py+size, fill=color, outline="")

        # Speaking bounce bars
        if self._state == "speaking":
            for i in range(7):
                bh = 10 + 15 * abs(math.sin(t * 5 + i * 0.8))
                bx = cx - 30 + i * 10
                c.create_rectangle(bx, cy + r + 15, bx + 6, cy + r + 15 + bh,
                                   fill="#00f7ff", outline="")

    def _animate_orb(self):
        if not self._orb_running:
            return
        self._orb_angle += 0.05
        self._draw_orb()
        if self.root:
            self.root.after(40, self._animate_orb)

    def set_state(self, state, rms=0):
        """state: idle | listening | speaking | thinking"""
        self._state = state
        self._orb_rms = rms
        labels = {
            "idle": "IDLE — READY", "listening": "LISTENING...",
            "speaking": "SPEAKING...", "thinking": "THINKING..."
        }
        if self.state_label:
            self.state_label.config(text=labels.get(state, state.upper()))

    def log(self, speaker, text):
        """Append a message to the console log."""
        if not self.console:
            return
        def _do():
            self.console.config(state=tk.NORMAL)
            time_str = time.strftime("%H:%M:%S")
            tag = speaker.lower() if speaker.lower() in ("nova", "user", "system", "error") else "system"
            self.console.insert(tk.END, f"[{time_str}] {speaker}: {text}\n", tag)
            self.console.see(tk.END)
            self.console.config(state=tk.DISABLED)
        if self.root:
            self.root.after(0, _do)

    def _safe_quit(self):
        self._orb_running = False
        if self.on_quit:
            self.on_quit()
        if self.root:
            self.root.destroy()

    def hide(self):
        if self.root:
            self.root.after(0, self.root.withdraw)

    def restore(self):
        if self.root:
            self.root.after(0, lambda: (
                self.root.deiconify(),
                self.root.lift(),
                self.root.focus_force()
            ))

