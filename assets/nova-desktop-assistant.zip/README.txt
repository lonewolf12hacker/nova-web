NOVA AI DESKTOP ASSISTANT
===========================

Setup Instructions:

1. Install Python 3.10 or newer:
   https://www.python.org/downloads/

2. Open your terminal or Command Prompt in this folder and install dependencies:
   pip install -r requirements.txt

3. Get your free ngrok authtoken:
   - Sign up at https://ngrok.com
   - Copy your token from the dashboard.

4. Create a text file named 'ngrok_token.txt' in the parent folder of the 'nova' package:
   E.g., if 'nova' is in 'C:\Users\Username\nova', place 'ngrok_token.txt' in 'C:\Users\Username\ngrok_token.txt'.
   Paste your authtoken in this file.

5. Start the assistant:
   python nova_start.py

6. Copy the 'Global URL' printed in the logs and paste it into the dashboard website connection settings!
